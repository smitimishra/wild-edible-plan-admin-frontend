import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthAnalysis } from './health-analysis';

describe('HealthAnalysis', () => {
  let component: HealthAnalysis;
  let fixture: ComponentFixture<HealthAnalysis>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HealthAnalysis],
    }).compileComponents();

    fixture = TestBed.createComponent(HealthAnalysis);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
