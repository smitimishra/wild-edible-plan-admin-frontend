import {
  Component,
  OnInit
} from '@angular/core';

import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';


// ============================================================
// HEALTH DATA MODELS
// ============================================================

interface HealthMetric {
  usage: number;
  status: string;
}


interface DiskMetric {
  drive: string;
  usage: number;
  status: string;
}


interface SystemHealth {
  cpu: HealthMetric;
  memory: HealthMetric;
  disk: DiskMetric;
}


// ============================================================
// ANGULAR SERVICE HEALTH
// ============================================================

interface AngularServiceHealth {
  status: string;
  httpStatus: number;
  responseTime: number;
  url: string;
  error?: string;
}


// ============================================================
// BACKEND SERVICE HEALTH
// ============================================================

interface BackendServiceHealth {
  status: string;
  port: number;
  responseTime: number;
  host: string;
  error?: string;
}


// ============================================================
// SERVICES HEALTH
// ============================================================

interface ServicesHealth {
  angular: AngularServiceHealth;
  backend: BackendServiceHealth;
}


// ============================================================
// HEALTH ALERTS
// ============================================================

interface HealthAlerts {
  warnings: string[];
  critical: string[];
}


// ============================================================
// COMPLETE HEALTH DATA
// ============================================================

interface HealthData {
  timestamp: string;
  computer: string;
  overallStatus: string;

  system: SystemHealth;

  services: ServicesHealth;

  alerts: HealthAlerts;
}


// ============================================================
// COMPONENT
// ============================================================

@Component({
  selector: 'app-health-analysis',
  standalone: true,

  imports: [
    CommonModule
  ],

  templateUrl: './health-analysis.html',

  styleUrl: './health-analysis.css'
})
export class HealthAnalysis implements OnInit {

  // ============================================================
  // DATA
  // ============================================================

  healthData: HealthData | null = null;


  // ============================================================
  // UI STATE
  // ============================================================

  loading = true;

  errorMessage = '';


  // ============================================================
  // CONSTRUCTOR
  // ============================================================

  constructor(
    private http: HttpClient
  ) {}


  // ============================================================
  // INIT
  // ============================================================

  ngOnInit(): void {

    this.loadHealthData();

  }


  // ============================================================
  // LOAD HEALTH DATA
  // ============================================================

  loadHealthData(): void {

    this.loading = true;

    this.errorMessage = '';

    this.http
      .get<HealthData>(
        'assets/health.json'
      )
      .subscribe({

        // --------------------------------------------------------
        // SUCCESS
        // --------------------------------------------------------

        next: (data) => {

          console.log(
            'Health Analysis data:',
            data
          );

          this.healthData = data;

          this.loading = false;

        },


        // --------------------------------------------------------
        // ERROR
        // --------------------------------------------------------

        error: (error) => {

          console.error(
            'Failed to load health data:',
            error
          );

          this.errorMessage =
            'Unable to load health analysis data.';

          this.loading = false;

        }

      });

  }


  // ============================================================
  // REFRESH
  // ============================================================

  refreshHealthData(): void {

    this.loadHealthData();

  }


  // ============================================================
  // STATUS HELPERS
  // ============================================================

  isCritical(
    status: string | undefined
  ): boolean {

    return (
      (status || '')
        .trim()
        .toUpperCase() === 'CRITICAL'
    );

  }


  isNormal(
    status: string | undefined
  ): boolean {

    return (
      (status || '')
        .trim()
        .toUpperCase() === 'NORMAL'
    );

  }


  isDown(
    status: string | undefined
  ): boolean {

    return (
      (status || '')
        .trim()
        .toUpperCase() === 'DOWN'
    );

  }


  isUp(
    status: string | undefined
  ): boolean {

    const normalized =
      (status || '')
        .trim()
        .toUpperCase();

    return (
      normalized === 'UP' ||
      normalized === 'RUNNING' ||
      normalized === 'ONLINE'
    );

  }


  // ============================================================
  // STATUS LABEL
  // ============================================================

  getStatusLabel(
    status: string | undefined
  ): string {

    if (!status) {

      return 'UNKNOWN';

    }

    return status
      .trim()
      .toUpperCase();

  }


  // ============================================================
  // RESPONSE TIME
  // ============================================================

  formatResponseTime(
    milliseconds: number | undefined
  ): string {

    if (
      milliseconds === undefined ||
      milliseconds === null
    ) {

      return '—';

    }

    if (milliseconds < 1000) {

      return `${milliseconds.toFixed(0)} ms`;

    }

    return `${(
      milliseconds / 1000
    ).toFixed(2)} s`;

  }


  // ============================================================
  // USAGE WIDTH
  // ============================================================

  getUsageWidth(
    usage: number | undefined
  ): string {

    if (
      usage === undefined ||
      usage === null
    ) {

      return '0%';

    }

    return `${Math.min(
      Math.max(usage, 0),
      100
    )}%`;

  }


  // ============================================================
  // ALERT TRACKING
  // ============================================================

  trackAlert(
    index: number,
    _alert: string
  ): number {

    return index;

  }

}